<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Episode;
use Illuminate\Http\Request;

class EpisodeController extends Controller
{
    public function index()
    {
        return Episode::with('podcast')->paginate(10);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'audio' => 'required|string',
            'podcast_id' => 'required|exists:podcasts,id',
        ]);

        $episode = Episode::create($validated);

        return response()->json($episode, 201);
    }

    public function show($id)
    {
        return Episode::with('podcast')->findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $episode = Episode::findOrFail($id);

        $validated = $request->validate([
            'title' => 'sometimes|required|string|max:255',
            'audio' => 'sometimes|required|string',
            'podcast_id' => 'sometimes|required|exists:podcasts,id',
        ]);

        $episode->update($validated);

        return response()->json($episode);
    }

    public function destroy($id)
    {
        $episode = Episode::findOrFail($id);
        $episode->delete();

        return response()->json(['message' => 'Episode deleted.']);
    }
}
