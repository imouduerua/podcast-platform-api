<?php

namespace App\Http\Controllers\Api;

use App\Models\Podcast;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PodcastController extends Controller
{
    /**
     * Display a listing of the resource.
     */

    public function index()
    {
        
        return Podcast::paginate(10); // Returns JSON with pagination meta
    }

    // ... other resource methods (store, show, update, destroy)

    public function episodes(Podcast $podcast)
    {
        return $podcast->episodes;
    }
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'category_id' => 'required|exists:categories,id'
        ]);

        $podcast = Podcast::create($validated);
        return response()->json($podcast, 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
