<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Category;
use App\Models\Podcast;
use App\Models\Episode;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        Category::factory(5)->create()->each(function ($category) {
            Podcast::factory(3)->create(['category_id' => $category->id])->each(function ($podcast) {
                Episode::factory(4)->create(['podcast_id' => $podcast->id]);
            });
        });
    }
}
