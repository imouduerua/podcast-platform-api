<?php
namespace Database\Factories;

use App\Models\Podcast;
use Illuminate\Database\Eloquent\Factories\Factory;

class EpisodeFactory extends Factory
{
    public function definition(): array
    {
        return [
            'title' => $this->faker->sentence,
            'audio' => $this->faker->url,
            'podcast_id' => Podcast::inRandomOrder()->first()->id ?? Podcast::factory(),
        ];
    }
}

