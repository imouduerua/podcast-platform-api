<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\PodcastController; // Ensure correct namespace

Route::middleware('api')->group(function () {
    // Podcast routes
    Route::apiResource('podcasts', PodcastController::class);
    
    // Additional routes (if needed)
    Route::get('podcasts/{podcast}/episodes', [PodcastController::class, 'episodes']);
});